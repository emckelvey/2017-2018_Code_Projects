# 2017-2018_Code_Projects
Websites, Front-End, Back-End Code / Including Ruby-On-Rails 
